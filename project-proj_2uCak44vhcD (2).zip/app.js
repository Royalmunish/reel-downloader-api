class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, errorInfo) {
    console.error('ErrorBoundary caught an error:', error, errorInfo.componentStack);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen flex items-center justify-center bg-gray-50">
          <div className="text-center p-8">
            <div className="icon-triangle-alert text-4xl text-red-500 mx-auto mb-4"></div>
            <h1 className="text-2xl font-bold text-gray-900 mb-2">Something went wrong</h1>
            <p className="text-gray-600 mb-6">We encountered an unexpected error.</p>
            <button
              onClick={() => window.location.reload()}
              className="bg-black text-white px-6 py-2 rounded-lg hover:bg-gray-800 transition-colors"
            >
              Reload Page
            </button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}

function App() {
  const [url, setUrl] = React.useState('');
  const [loading, setLoading] = React.useState(false);
  const [result, setResult] = React.useState(null);
  const [error, setError] = React.useState('');
  const [trendingReels, setTrendingReels] = React.useState([]);
  const [loadingTrending, setLoadingTrending] = React.useState(true);

  // Fetch trending reels on mount
  React.useEffect(() => {
    fetchTrendingReels();
  }, []);

  const fetchTrendingReels = async () => {
    try {
      // Using internal trickleListObjects API
      // objectType, limit, descent (sort by latest), nextPageToken
      const response = await trickleListObjects('downloaded_reel', 8, true);
      if (response && response.items) {
        setTrendingReels(response.items);
      }
    } catch (err) {
      console.error('Failed to fetch trending reels:', err);
    } finally {
      setLoadingTrending(false);
    }
  };

  const handleDownload = async (e) => {
    e.preventDefault();
    setError('');
    setResult(null);

    if (!url.trim()) {
      setError('Please paste a valid Instagram URL');
      return;
    }

    if (!url.includes('instagram.com')) {
      setError('This does not look like a valid Instagram URL');
      return;
    }

    setLoading(true);

    // Simulate API processing
    setTimeout(async () => {
      setLoading(false);
      
      const mockResult = {
        thumbnail: 'https://images.unsplash.com/photo-1611162617213-7d7a39e9b1d7?w=600&auto=format&fit=crop&q=60',
        author: '@instagram_user',
        caption: 'Checking out this amazing view! #nature #travel #reels',
        likes: '12.5k',
        views: '45.2k',
        type: 'Reel',
        original_url: url
      };

      setResult(mockResult);

      // Save to database as a new "download"
      try {
        await trickleCreateObject('downloaded_reel', mockResult);
        // Refresh trending list to show the new one
        fetchTrendingReels();
      } catch (err) {
        console.error('Failed to save to history:', err);
      }

    }, 2000);
  };

  return (
    <div className="min-h-screen flex flex-col bg-gray-50" data-name="app" data-file="app.js">
      <Header />
      
      <main className="flex-grow">
        <Hero 
          url={url} 
          setUrl={setUrl} 
          handleDownload={handleDownload} 
          loading={loading}
          error={error}
        />
        
        {result && <DownloadResult data={result} onClose={() => {setResult(null); setUrl('');}} />}
        
        <TrendingGallery reels={trendingReels} loading={loadingTrending} />

        <Features />
        <HowTo />
        <Faq />
      </main>

      <Footer />
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <ErrorBoundary>
    <App />
  </ErrorBoundary>
);