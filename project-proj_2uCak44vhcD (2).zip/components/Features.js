function Features() {
  const features = [
    {
      icon: "icon-zap",
      title: "Lightning Fast",
      desc: "Our servers process videos in seconds. Get your content immediately without waiting."
    },
    {
      icon: "icon-smartphone",
      title: "All Devices Support",
      desc: "Works perfectly on iPhone, Android, iPad, Tablet, Mac, and Windows computers."
    },
    {
      icon: "icon-shield-check",
      title: "100% Safe & Secure",
      desc: "We do not store your downloads or track your history. Your privacy is guaranteed."
    },
    {
      icon: "icon-video",
      title: "High Quality MP4",
      desc: "Download videos in their original resolution. Supports HD, Full HD, and 4K downloads."
    },
    {
      icon: "icon-user-round",
      title: "No Login Required",
      desc: "You don't need an Instagram account to download public reels or videos."
    },
    {
      icon: "icon-coins",
      title: "Completely Free",
      desc: "Use our service as much as you want. No hidden fees, subscriptions, or limits."
    }
  ];

  return (
    <section id="features" className="py-20 bg-white" data-name="Features" data-file="components/Features.js">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Why Choose InstaSaver?</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            We provide the best tool to save Instagram content effortlessly.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((item, index) => (
            <div key={index} className="card group">
              <div className="w-14 h-14 rounded-2xl bg-pink-50 flex items-center justify-center mb-6 group-hover:bg-gradient-to-br group-hover:from-yellow-400 group-hover:to-pink-500 transition-all duration-300">
                <div className={`${item.icon} text-2xl text-pink-600 group-hover:text-white transition-colors`}></div>
              </div>
              <h3 className="text-xl font-bold mb-3 text-gray-900">{item.title}</h3>
              <p className="text-gray-500 leading-relaxed">
                {item.desc}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}