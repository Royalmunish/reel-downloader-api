function DownloadResult({ data, onClose }) {
  if (!data) return null;

  return (
    <section className="py-10 px-4 animate-fade-in" data-name="DownloadResult" data-file="components/DownloadResult.js">
      <div className="max-w-md mx-auto bg-white rounded-3xl shadow-xl overflow-hidden border border-gray-100">
        <div className="p-4 border-b border-gray-50 flex justify-between items-center bg-gray-50/50">
          <h3 className="font-bold text-gray-800 flex items-center">
            <div className="icon-circle-check text-green-500 mr-2"></div>
            Ready to Download
          </h3>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600">
            <div className="icon-x"></div>
          </button>
        </div>
        
        <div className="p-6">
          <div className="relative aspect-[9/16] bg-gray-100 rounded-xl overflow-hidden mb-6 group">
            <img src={data.thumbnail} alt="Thumbnail" className="w-full h-full object-cover" />
            <div className="absolute inset-0 bg-black/20 group-hover:bg-black/40 transition-colors flex items-center justify-center">
                <div className="w-16 h-16 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center text-white cursor-pointer hover:scale-110 transition-transform">
                    <div className="icon-play fill-white text-3xl ml-1"></div>
                </div>
            </div>
          </div>
          
          <div className="space-y-4">
            <div className="flex items-center space-x-3 text-sm text-gray-600">
               <div className="w-8 h-8 bg-gray-200 rounded-full flex items-center justify-center text-xs font-bold text-gray-500">
                 {data.author.substring(1,3).toUpperCase()}
               </div>
               <span className="font-semibold text-gray-900">{data.author}</span>
            </div>
            
            <p className="text-sm text-gray-500 line-clamp-2">{data.caption}</p>
            
            <div className="flex justify-between text-xs text-gray-400 border-t border-gray-100 pt-3">
               <span className="flex items-center"><div className="icon-heart mr-1 w-3"></div> {data.likes}</span>
               <span className="flex items-center"><div className="icon-eye mr-1 w-3"></div> {data.views}</span>
            </div>

            <button className="w-full btn-gradient flex items-center justify-center py-3.5 mt-2">
              <div className="icon-download mr-2 text-lg"></div>
              Download MP4
            </button>
            <button className="w-full bg-gray-100 hover:bg-gray-200 text-gray-800 font-semibold py-3 px-6 rounded-full transition-colors flex items-center justify-center">
               Download Thumbnail
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}