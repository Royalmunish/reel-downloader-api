function Faq() {
  const [openIndex, setOpenIndex] = React.useState(0);

  const faqs = [
    {
      q: "Is InstaSaver really free?",
      a: "Yes, our tool is 100% free to use. You can download as many videos as you want without paying anything."
    },
    {
      q: "Can I download private Instagram Reels?",
      a: "No, currently we only support downloading content from public Instagram accounts due to privacy policies."
    },
    {
      q: "Where are the videos saved?",
      a: "Videos are usually saved in the 'Downloads' folder on your PC or mobile device (Android/iOS)."
    },
    {
      q: "Does it work on iPhone/iPad?",
      a: "Yes! It works perfectly on Safari, Chrome, or any browser on your iOS device."
    },
    {
      q: "Do you store the downloaded videos?",
      a: "No, we do not store any videos or track your download history. We only act as a bridge to help you download directly from Instagram."
    }
  ];

  return (
    <section id="faq" className="py-20 bg-white" data-name="Faq" data-file="components/Faq.js">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-3xl md:text-4xl font-bold mb-12 text-center">Frequently Asked Questions</h2>
        
        <div className="space-y-4">
          {faqs.map((item, index) => (
            <div key={index} className="border border-gray-200 rounded-2xl overflow-hidden">
              <button 
                className="w-full flex justify-between items-center p-5 text-left bg-white hover:bg-gray-50 transition-colors"
                onClick={() => setOpenIndex(openIndex === index ? -1 : index)}
              >
                <span className="font-semibold text-lg text-gray-800">{item.q}</span>
                <div className={`transform transition-transform duration-200 ${openIndex === index ? 'rotate-180' : ''}`}>
                  <div className="icon-chevron-down text-gray-400"></div>
                </div>
              </button>
              
              <div 
                className={`transition-all duration-300 ease-in-out overflow-hidden ${openIndex === index ? 'max-h-40 opacity-100' : 'max-h-0 opacity-0'}`}
              >
                <div className="p-5 pt-0 text-gray-600 bg-gray-50/50">
                  {item.a}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}