function Header() {
  return (
    <nav className="bg-white/80 backdrop-blur-md sticky top-0 z-50 border-b border-gray-100" data-name="Header" data-file="components/Header.js">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center cursor-pointer" onClick={() => window.location.reload()}>
            <div className="bg-gradient-to-tr from-yellow-400 via-red-500 to-purple-500 p-1.5 rounded-lg mr-2">
              <div className="icon-instagram text-white text-xl"></div>
            </div>
            <span className="text-2xl font-bold tracking-tight">Insta<span className="text-pink-600">Saver</span></span>
          </div>
          
          <div className="hidden md:flex space-x-8">
            <a href="#features" className="text-gray-600 hover:text-pink-600 font-medium transition-colors">Features</a>
            <a href="#howto" className="text-gray-600 hover:text-pink-600 font-medium transition-colors">How to Use</a>
            <a href="#faq" className="text-gray-600 hover:text-pink-600 font-medium transition-colors">FAQ</a>
          </div>

          <div className="md:hidden">
            <button className="text-gray-600 hover:text-gray-900">
              <div className="icon-menu text-2xl"></div>
            </button>
          </div>
        </div>
      </div>
    </nav>
  );
}