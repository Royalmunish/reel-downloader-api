function Hero({ url, setUrl, handleDownload, loading, error }) {
  return (
    <section className="relative pt-20 pb-24 px-4 overflow-hidden" data-name="Hero" data-file="components/Hero.js">
      {/* Background blobs */}
      <div className="absolute top-20 left-[-100px] w-64 h-64 bg-purple-300 rounded-full mix-blend-multiply filter blur-3xl opacity-30 animate-blob"></div>
      <div className="absolute top-20 right-[-100px] w-64 h-64 bg-yellow-300 rounded-full mix-blend-multiply filter blur-3xl opacity-30 animate-blob animation-delay-2000"></div>
      <div className="absolute -bottom-8 left-20 w-64 h-64 bg-pink-300 rounded-full mix-blend-multiply filter blur-3xl opacity-30 animate-blob animation-delay-4000"></div>

      <div className="max-w-4xl mx-auto text-center relative z-10">
        <h1 style={{"paddingTop":"0px","paddingRight":"0px","paddingBottom":"0px","paddingLeft":"0px","marginTop":"0px","marginRight":"0px","marginBottom":"24px","marginLeft":"0px","fontSize":"36px","color":"rgb(38, 38, 38)","backgroundColor":"rgba(0, 0, 0, 0)","textAlign":"center","fontWeight":"300","objectFit":"fill","display":"block","position":"static","top":"auto","left":"auto","right":"auto","bottom":"auto"}} className="text-4xl md:text-6xl font-extrabold mb-6 tracking-tight">
          Download Instagram Reels 
          <br />
          <span className="insta-gradient-text">Without Watermark</span>
        </h1>
        <p className="text-lg md:text-xl text-gray-600 mb-10 max-w-2xl mx-auto">
          Save Reels, Videos, Photos, and Stories from Instagram directly to your gallery. Fast, free, and unlimited downloads.
        </p>

        <form onSubmit={handleDownload} className="max-w-2xl mx-auto relative group">
          <div className="relative flex items-center">
            <div className="absolute left-4 text-gray-400">
               <div className="icon-link text-xl"></div>
            </div>
            <input 
              type="text" 
              placeholder="Paste Instagram link here..." 
              className="input-main pl-12 pr-36 h-16 shadow-lg"
              value={url}
              onChange={(e) => setUrl(e.target.value)}
            />
            <button 
              type="submit" 
              className="absolute right-2 top-2 bottom-2 btn-gradient flex items-center justify-center min-w-[120px]"
              disabled={loading}
            >
              {loading ? (
                <div className="animate-spin rounded-full h-5 w-5 border-2 border-white border-t-transparent"></div>
              ) : (
                <>
                  <span>Download</span>
                  <div className="icon-arrow-right ml-2 text-lg"></div>
                </>
              )}
            </button>
          </div>
          {error && (
            <div className="mt-3 text-red-500 bg-red-50 inline-block px-4 py-1 rounded-md text-sm font-medium border border-red-100 flex items-center mx-auto w-fit animate-bounce">
              <div className="icon-circle-alert mr-2 text-sm"></div>
              {error}
            </div>
          )}
        </form>

        <div className="mt-8 flex justify-center space-x-6 text-gray-500 text-sm">
          <div className="flex items-center">
            <div className="icon-check text-green-500 mr-1.5 text-base"></div> No Watermark
          </div>
          <div className="flex items-center">
            <div className="icon-check text-green-500 mr-1.5 text-base"></div> HD Quality
          </div>
          <div className="flex items-center">
            <div className="icon-check text-green-500 mr-1.5 text-base"></div> Unlimited
          </div>
        </div>
      </div>
    </section>
  );
}