function HowTo() {
  const steps = [
    {
      num: "01",
      title: "Copy the Link",
      desc: "Open Instagram app or website, find the Reel you want to download, tap the (•••) or Share icon and copy the link."
    },
    {
      num: "02",
      title: "Paste & Click",
      desc: "Go back to InstaSaver, paste the link into the input field above and hit the 'Download' button."
    },
    {
      num: "03",
      title: "Save Video",
      desc: "Wait for a few seconds while we process the video, then click 'Download MP4' to save it to your device."
    }
  ];

  return (
    <section id="howto" className="py-20 bg-gray-50" data-name="HowTo" data-file="components/HowTo.js">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">How to Download Reels?</h2>
          <p className="text-gray-600">It's super easy! Just follow these 3 simple steps.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 relative">
           {/* Connecting line for desktop */}
           <div className="hidden md:block absolute top-12 left-[16%] right-[16%] h-0.5 bg-gray-200 -z-0"></div>

          {steps.map((step, index) => (
            <div key={index} className="relative z-10 text-center">
              <div className="w-24 h-24 mx-auto bg-white rounded-full shadow-md flex items-center justify-center mb-6 border-4 border-gray-50">
                <span className="text-3xl font-black insta-gradient-text">{step.num}</span>
              </div>
              <h3 className="text-xl font-bold mb-3">{step.title}</h3>
              <p className="text-gray-500 px-4">
                {step.desc}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}