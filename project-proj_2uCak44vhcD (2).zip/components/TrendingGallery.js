function TrendingGallery({ reels, loading }) {
  if (loading) {
    return (
      <section className="py-20 bg-gray-50 border-t border-gray-100" data-name="TrendingGallery" data-file="components/TrendingGallery.js">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
           <div className="text-center mb-12">
             <div className="h-8 w-64 bg-gray-200 rounded-full mx-auto mb-4 animate-pulse"></div>
             <div className="h-4 w-96 bg-gray-200 rounded-full mx-auto animate-pulse"></div>
           </div>
           <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6">
             {[1, 2, 3, 4].map((i) => (
               <div key={i} className="aspect-[9/16] bg-gray-200 rounded-2xl animate-pulse"></div>
             ))}
           </div>
        </div>
      </section>
    );
  }

  if (!reels || reels.length === 0) return null;

  return (
    <section id="trending" className="py-20 bg-gray-50 border-t border-gray-100" data-name="TrendingGallery" data-file="components/TrendingGallery.js">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Trending Now</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            See what other users are downloading right now.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6">
          {reels.map((item) => {
            const data = item.objectData;
            return (
              <div key={item.objectId} className="group relative bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1">
                {/* Thumbnail */}
                <div className="aspect-[9/16] relative overflow-hidden bg-gray-100">
                  <img 
                    src={data.thumbnail} 
                    alt={data.caption || "Instagram Reel"} 
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                    onError={(e) => e.target.src = 'https://images.unsplash.com/photo-1611162616475-46b635cb6868?w=600&auto=format&fit=crop&q=60'} 
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-60"></div>
                  
                  {/* Play Icon Overlay */}
                  <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300 bg-black/20 backdrop-blur-[2px]">
                    <div className="w-12 h-12 bg-white/20 backdrop-blur-md rounded-full flex items-center justify-center text-white">
                      <div className="icon-play fill-white ml-1 text-xl"></div>
                    </div>
                  </div>

                  {/* Stats Overlay */}
                  <div className="absolute bottom-0 left-0 right-0 p-4 text-white transform translate-y-2 group-hover:translate-y-0 transition-transform duration-300">
                    <div className="flex items-center text-sm font-medium mb-1">
                      <div className="icon-user-round w-4 h-4 mr-1.5 opacity-80"></div>
                      <span className="truncate">{data.author}</span>
                    </div>
                    <div className="flex justify-between items-center text-xs opacity-80">
                      <span className="flex items-center"><div className="icon-heart w-3 h-3 mr-1"></div> {data.likes}</span>
                      <span className="flex items-center"><div className="icon-eye w-3 h-3 mr-1"></div> {data.views}</span>
                    </div>
                  </div>
                </div>
                
                {/* External Link Action */}
                <a 
                  href={data.original_url} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="absolute top-3 right-3 w-8 h-8 bg-white/90 backdrop-blur rounded-full flex items-center justify-center text-gray-900 opacity-0 group-hover:opacity-100 transition-all duration-300 hover:bg-pink-500 hover:text-white"
                  title="View on Instagram"
                >
                  <div className="icon-external-link w-4 h-4"></div>
                </a>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}