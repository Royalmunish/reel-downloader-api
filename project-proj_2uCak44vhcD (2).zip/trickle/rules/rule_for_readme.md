When updating the project:
- Check if the `trickle/notes/README.md` needs to be updated to reflect new features or architectural changes.
- Keep the feature list in README up to date.
- Document any new external libraries added.