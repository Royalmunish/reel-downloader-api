# InstaSaver Project

This is a frontend implementation of an Instagram Reel Downloader website.

## Features
- Modern, responsive UI with Instagram-like gradient branding.
- URL input validation.
- Simulated download process (with loading state and result card).
- **Trending Gallery**: Displays recently downloaded reels fetched from Trickle database.
- Features, How-to, and FAQ sections.
- Error handling for invalid inputs.

## Technical Details
- Built with React 18.
- Styled with TailwindCSS.
- Icons by Lucide.
- **Database**: Integrated with Trickle Database (`downloaded_reel` table) to store and retrieve download history.
- No backend logic (Download functionality is simulated for demo purposes).

## Maintenance
- Ensure Tailwind classes are updated if the design system changes.
- Check `trickle/rules` for specific coding guidelines.